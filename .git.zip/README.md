- 👋 Hi, I’m @NeckitWin
- 👀 I’m interested in IT, guitar and volleyball
- 🌱 I’m currently learning in toilet
- 💞️ I’m looking to collaborate on internet
- 📫 How to reach me in toilet

<!---
NeckitWin/NeckitWin is a ✨ special ✨ repository because its `README.md` (this file) appears on your GitHub profile.
You can click the Preview link to take a look at your changes.
--->
